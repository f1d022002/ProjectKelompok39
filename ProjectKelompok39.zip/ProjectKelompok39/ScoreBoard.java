import java.awt.*;
import java.sql.*;
import javax.swing.*;

public class ScoreBoard extends JFrame {

    private JPanel scoresPanel;
    private JScrollPane scrollPane;

    public ScoreBoard() {
        setupUI();
        loadScores();
    }

    // Setup tampilan UI
    private void setupUI() {
        // Frame untuk ScoreBoard
        setTitle("Score Board");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);  // Center the window
        setLayout(new BorderLayout());

        // Background panel dengan warna gradien
        JPanel backgroundPanel = createBackgroundPanel();
        backgroundPanel.setLayout(new BorderLayout());

        // Panel judul
        JPanel topPanel = createTopPanel();
        backgroundPanel.add(topPanel, BorderLayout.NORTH);

        // Header kolom
        JPanel headerPanel = createHeaderPanel();

        // Panel untuk menampilkan skor
        scoresPanel = createScoresPanel();

        // Scroll untuk panel skor
        scrollPane = createScrollPane();
        
        // Panel utama
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setOpaque(false);
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        backgroundPanel.add(mainPanel, BorderLayout.CENTER);
        add(backgroundPanel);

        setVisible(true);
    }

    // Method untuk membuat panel latar belakang dengan gradien
    private JPanel createBackgroundPanel() {
        return new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Color color1 = new Color(200, 230, 255);
                Color color2 = new Color(180, 216, 255);
                GradientPaint gradient = new GradientPaint(0, 0, color1, 0, getHeight(), color2);
                ((Graphics2D) g).setPaint(gradient);
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
    }

    // Method untuk membuat panel judul
    private JPanel createTopPanel() {
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);

        JLabel titleLabel = new JLabel("SCORE PEMAIN", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 40));
        titleLabel.setForeground(new Color(174, 158, 108));
        topPanel.add(titleLabel, BorderLayout.CENTER);

        return topPanel;
    }

    // Method untuk membuat header kolom
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new GridLayout(1, 2, 20, 0));
        headerPanel.setOpaque(false);

        JLabel playerHeader = new JLabel("PLAYER", SwingConstants.CENTER);
        JLabel pointHeader = new JLabel("POINT", SwingConstants.CENTER);

        playerHeader.setFont(new Font("Arial", Font.BOLD, 20));
        pointHeader.setFont(new Font("Arial", Font.BOLD, 20));

        playerHeader.setForeground(new Color(194, 178, 128));
        pointHeader.setForeground(new Color(194, 178, 128));

        headerPanel.add(playerHeader);
        headerPanel.add(pointHeader);

        return headerPanel;
    }

    // Method untuk membuat panel skor
    private JPanel createScoresPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);
        return panel;
    }

    // Method untuk membuat scroll pane
    private JScrollPane createScrollPane() {
        JScrollPane scrollPane = new JScrollPane(scoresPanel);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        return scrollPane;
    }

    // Method untuk mengambil dan menampilkan skor dari database
    private void loadScores() {
        // Membuka koneksi ke database
        DatabaseHelper dbHelper = new DatabaseHelper();
        ResultSet resultSet = dbHelper.getScores();

        try {
            // Jika ada hasil dari database
            if (resultSet != null) {
                while (resultSet.next()) {
                    String playerName = resultSet.getString("player_name");
                    int score = resultSet.getInt("score");

                    JPanel rowPanel = createRowPanel(playerName, score);
                    scoresPanel.add(rowPanel);
                }
            } else {
                // Jika tidak ada data
                JLabel noDataLabel = createNoDataLabel();
                scoresPanel.add(noDataLabel);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JLabel errorLabel = createErrorLabel();
            scoresPanel.add(errorLabel);
        }
    }

    // Method untuk membuat panel baris skor
    private JPanel createRowPanel(String playerName, int score) {
        JPanel rowPanel = new JPanel(new GridLayout(1, 2, 20, 0));
        rowPanel.setOpaque(false);
        rowPanel.setBorder(BorderFactory.createEmptyBorder(5, 190, 5, 190));

        JLabel playerLabel = new JLabel(playerName, SwingConstants.LEFT);
        playerLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        playerLabel.setForeground(new Color(194, 178, 128));

        JLabel scoreLabel = new JLabel(String.valueOf(score), SwingConstants.RIGHT);
        scoreLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        scoreLabel.setForeground(new Color(194, 178, 128));

        rowPanel.add(playerLabel);
        rowPanel.add(scoreLabel);

        return rowPanel;
    }

    // Method untuk membuat label jika tidak ada data
    private JLabel createNoDataLabel() {
        JLabel label = new JLabel("Tidak ada skor yang tersedia.", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.PLAIN, 20));
        label.setForeground(new Color(194, 178, 128));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    // Method untuk membuat label error
    private JLabel createErrorLabel() {
        JLabel label = new JLabel("Gagal mengambil skor.", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.PLAIN, 20));
        label.setForeground(Color.RED);
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        return label;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ScoreBoard::new);
    }
}
