import java.awt.*;
import javax.swing.*;

public class BackgroundPanel extends JPanel {
    private Image backgroundImage;  // Menyimpan gambar latar belakang

    // Constructor yang menerima path gambar
    public BackgroundPanel(String imagePath) {
        // Memuat gambar menggunakan path yang diberikan
        ImageIcon icon = new ImageIcon(imagePath);
        this.backgroundImage = icon.getImage();
    }

    // Override paintComponent untuk menggambar gambar latar belakang
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // Menggambar gambar latar belakang
        g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
    }
}
